package com.xg99.translator

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    companion object {
        const val ACTION_REQUEST_SYSTEM = "com.xg99.translator.action.REQUEST_SYSTEM"
    }

    private var pendingAction: (() -> Unit)? = null

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val action = pendingAction
            pendingAction = null
            if (hasMicPermission()) {
                action?.invoke()
            } else {
                AppState.log("❌ Permission micro refusée — indispensable à la traduction")
            }
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == Activity.RESULT_OK && data != null) {
                val intent = TranslatorService.intent(this, TranslatorService.ACTION_PROJECTION)
                    .putExtra(TranslatorService.EXTRA_RESULT_CODE, result.resultCode)
                    .putExtra(TranslatorService.EXTRA_RESULT_DATA, data)
                ContextCompat.startForegroundService(this, intent)
            } else {
                AppState.log("❌ Capture du son du téléphone refusée")
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            XG99Theme {
                TranslatorScreen(
                    onMic = { startMicMode() },
                    onSystem = { startSystemMode() },
                    onStop = { stopAll() }
                )
            }
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent != null && intent.action == ACTION_REQUEST_SYSTEM) {
            intent.action = null
            startSystemMode()
        }
    }

    private fun hasMicPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED

    private fun withPermissions(action: () -> Unit) {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 31) needed.add(Manifest.permission.BLUETOOTH_CONNECT)
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            action()
        } else {
            pendingAction = action
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun hasApiKey(): Boolean {
        if (Prefs.apiKey(this).isBlank()) {
            Toast.makeText(this, "Collez d'abord votre clé API Gemini", Toast.LENGTH_LONG).show()
            AppState.log("❌ Clé API Gemini manquante")
            return false
        }
        return true
    }

    private fun startMicMode() {
        if (!hasApiKey()) return
        withPermissions {
            ContextCompat.startForegroundService(
                this, TranslatorService.intent(this, TranslatorService.ACTION_START_MIC)
            )
        }
    }

    private fun startSystemMode() {
        if (!hasApiKey()) return
        withPermissions {
            if (AppState.hasProjection.value) {
                ContextCompat.startForegroundService(
                    this, TranslatorService.intent(this, TranslatorService.ACTION_START_SYSTEM)
                )
            } else {
                val manager = getSystemService(MediaProjectionManager::class.java)
                val captureIntent = if (Build.VERSION.SDK_INT >= 34) {
                    manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
                } else {
                    manager.createScreenCaptureIntent()
                }
                AppState.log("Autorisez la capture : seul le SON est utilisé, l'écran n'est pas enregistré")
                projectionLauncher.launch(captureIntent)
            }
        }
    }

    private fun stopAll() {
        try {
            startService(TranslatorService.intent(this, TranslatorService.ACTION_STOP))
        } catch (e: Exception) {
            AppState.log("Arrêt impossible : ${e.message}")
        }
    }
}

/* ============================================================
 *  Interface Jetpack Compose (thème sombre, écran unique)
 * ============================================================ */

private val Accent = Color(0xFF4FC3F7)
private val Green = Color(0xFF66BB6A)
private val Blue = Color(0xFF42A5F5)
private val Red = Color(0xFFEF5350)
private val Orange = Color(0xFFFFA726)
private val Muted = Color(0xFF8B949E)

@Composable
private fun XG99Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            secondary = Green,
            background = Color(0xFF0E1116),
            surface = Color(0xFF161B22),
            onBackground = Color(0xFFE6EDF3),
            onSurface = Color(0xFFE6EDF3),
            error = Red
        ),
        content = content
    )
}

@Composable
private fun TranslatorScreen(onMic: () -> Unit, onSystem: () -> Unit, onStop: () -> Unit) {
    val context = LocalContext.current
    var apiKey by remember { mutableStateOf(Prefs.apiKey(context)) }
    var showKey by remember { mutableStateOf(false) }
    var model by remember { mutableStateOf(Prefs.model(context)) }
    var source by remember { mutableStateOf(Prefs.source(context)) }
    var target by remember { mutableStateOf(Prefs.target(context)) }
    val mode by AppState.mode.collectAsState()
    val logs by AppState.logs.collectAsState()

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Header(mode) }

            item {
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = {
                        apiKey = it
                        Prefs.save(context, Prefs.KEY_API, it.trim())
                    },
                    label = { Text("Clé API Gemini") },
                    singleLine = true,
                    visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        TextButton(onClick = { showKey = !showKey }) {
                            Text(if (showKey) "Masquer" else "Voir")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.fillMaxWidth()) {
                    LanguagePicker("Ma langue", source, Modifier.weight(1f)) {
                        source = it
                        Prefs.save(context, Prefs.KEY_SRC, it.code)
                    }
                    TextButton(
                        onClick = {
                            val s = source
                            source = target
                            target = s
                            Prefs.save(context, Prefs.KEY_SRC, source.code)
                            Prefs.save(context, Prefs.KEY_TGT, target.code)
                        }
                    ) { Text("⇄", fontSize = 22.sp) }
                    LanguagePicker("Traduire vers", target, Modifier.weight(1f)) {
                        target = it
                        Prefs.save(context, Prefs.KEY_TGT, it.code)
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = model,
                    onValueChange = {
                        model = it
                        Prefs.save(context, Prefs.KEY_MODEL, it.trim())
                    },
                    label = { Text("Modèle Gemini Live") },
                    singleLine = true,
                    supportingText = {
                        Text(
                            "« gemini-3.5-live-translate-preview » = traducteur dédié (vers la langue cible). " +
                                "« gemini-3.8-live » = interprète bidirectionnel automatique.",
                            fontSize = 11.sp
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    BigButton("🎙  Traduire mon Micro", Green, mode == Mode.MIC, onMic)
                    BigButton("📱  Traduire le Son du Téléphone", Blue, mode == Mode.SYSTEM, onSystem)
                    BigButton("⏹  Arrêter", Red, mode == Mode.IDLE, onStop)
                }
            }

            item {
                Text(
                    "Bouton des écouteurs : 1 appui = Micro → Système → Pause. " +
                        "Les réglages s'appliquent au prochain démarrage d'un mode.",
                    color = Muted,
                    fontSize = 12.sp
                )
            }

            item {
                Spacer(Modifier.height(4.dp))
                Text("Journal en direct", fontWeight = FontWeight.Bold, color = Accent)
            }

            items(logs) { line ->
                Text(
                    text = line,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun Header(mode: Mode) {
    val color = when (mode) {
        Mode.MIC -> Green
        Mode.SYSTEM -> Blue
        Mode.PAUSED -> Orange
        Mode.IDLE -> Muted
    }
    Column {
        Text(
            "Traducteur XG99",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(Modifier.width(8.dp))
            Text("État : ${mode.label}", color = color, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun LanguagePicker(
    label: String,
    selected: Lang,
    modifier: Modifier = Modifier,
    onSelect: (Lang) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Column(modifier) {
        Text(label, color = Muted, fontSize = 12.sp)
        Box {
            OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                Text(selected.label, maxLines = 1)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                LANGUAGES.forEach { lang ->
                    DropdownMenuItem(
                        text = { Text(lang.label) },
                        onClick = {
                            expanded = false
                            onSelect(lang)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun BigButton(text: String, color: Color, active: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(64.dp),
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (active) color else color.copy(alpha = 0.35f),
            contentColor = Color.White
        )
    ) {
        Text(text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}
