package com.xg99.translator

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaMetadata
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcelable
import android.os.PowerManager
import android.view.KeyEvent
import androidx.core.app.NotificationCompat
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

private const val IN_RATE = 16000                 // Gemini attend du PCM 16 kHz
private const val OUT_RATE = 24000                // Gemini renvoie du PCM 24 kHz
private const val CHUNK_BYTES = IN_RATE * 2 / 10  // 100 ms de PCM 16 bits mono

@Suppress("DEPRECATION")
private inline fun <reified T : Parcelable> Intent.parcelable(key: String): T? =
    if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(key, T::class.java) else getParcelableExtra(key)

/* ============================================================
 *  Lecteur PCM temps réel (AudioTrack en streaming, thread dédié)
 * ============================================================ */

private class PcmPlayer(usage: Int) {
    private val queue = LinkedBlockingQueue<ByteArray>()

    @Volatile
    private var running = true

    @Volatile
    private var flushRequested = false

    private val track: AudioTrack

    init {
        val min = AudioTrack.getMinBufferSize(
            OUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(OUT_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(min * 2, OUT_RATE / 2))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track.play()
        Thread({ loop() }, "xg99-player").start()
    }

    fun enqueue(pcm: ByteArray) {
        if (running) queue.offer(pcm)
    }

    fun flush() {
        flushRequested = true
    }

    fun release() {
        running = false
    }

    private fun loop() {
        try {
            while (running) {
                if (flushRequested) {
                    flushRequested = false
                    queue.clear()
                    try {
                        track.pause()
                        track.flush()
                        track.play()
                    } catch (ignored: Exception) {
                    }
                }
                val chunk = (try {
                    queue.poll(100, TimeUnit.MILLISECONDS)
                } catch (ignored: InterruptedException) {
                    null
                }) ?: continue
                track.write(chunk, 0, chunk.size)
            }
        } catch (e: Exception) {
            AppState.log("Lecture audio interrompue : ${e.message}")
        } finally {
            try {
                track.stop()
            } catch (ignored: Exception) {
            }
            track.release()
        }
    }
}

/* ============================================================
 *  Service de premier plan : capture, routage BT, Gemini, boutons
 * ============================================================ */

class TranslatorService : Service() {

    companion object {
        const val ACTION_START_MIC = "com.xg99.translator.action.START_MIC"
        const val ACTION_START_SYSTEM = "com.xg99.translator.action.START_SYSTEM"
        const val ACTION_PROJECTION = "com.xg99.translator.action.PROJECTION"
        const val ACTION_PAUSE = "com.xg99.translator.action.PAUSE"
        const val ACTION_TOGGLE = "com.xg99.translator.action.TOGGLE"
        const val ACTION_STOP = "com.xg99.translator.action.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"

        private const val CHANNEL_ID = "xg99_translator"
        private const val NOTIF_ID = 1099
        private const val MAX_RECONNECT = 5

        fun intent(context: Context, action: String): Intent =
            Intent(context, TranslatorService::class.java).setAction(action)
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var audioManager: AudioManager
    private lateinit var mediaSession: MediaSession

    private var mode = Mode.IDLE
    private var currentFgsTypes = -1
    private var projectionGrantPending = false
    private var projection: MediaProjection? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var focusRequest: AudioFocusRequest? = null
    private var routedToBluetooth = false
    private var mediaMuted = false
    private var echoCanceler: AcousticEchoCanceler? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private var captureThread: Thread? = null
    private var reconnectAttempts = 0
    private var shuttingDown = false

    @Volatile
    private var sessionGen = 0

    @Volatile
    private var capturing = false

    @Volatile
    private var client: GeminiLiveClient? = null

    @Volatile
    private var player: PcmPlayer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createChannel()
        setupMediaSession()
        AppState.log("Service démarré")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_MIC -> if (ensureForeground()) switchTo(Mode.MIC) else stopSelf()
            ACTION_START_SYSTEM -> if (ensureForeground()) switchTo(Mode.SYSTEM) else stopSelf()
            ACTION_PROJECTION -> handleProjection(intent)
            ACTION_PAUSE -> if (ensureForeground()) switchTo(Mode.PAUSED)
            ACTION_TOGGLE -> if (ensureForeground()) cycle()
            ACTION_STOP -> shutdown()
            else -> ensureForeground()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopSession()
        releaseProjection()
        try {
            mediaSession.isActive = false
            mediaSession.release()
        } catch (ignored: Exception) {
        }
        mode = Mode.IDLE
        AppState.mode.value = Mode.IDLE
        super.onDestroy()
    }

    /* ---------------- Premier plan & notification ---------------- */

    private fun ensureForeground(): Boolean {
        var types = 0
        if (Build.VERSION.SDK_INT >= 30) {
            types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        if (projection != null || projectionGrantPending) {
            types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        }
        if (types == currentFgsTypes) {
            updateNotification()
            return true
        }
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, buildNotification(), types)
            } else {
                startForeground(NOTIF_ID, buildNotification())
            }
            currentFgsTypes = types
            true
        } catch (e: Exception) {
            AppState.log("❌ Impossible de passer au premier plan : ${e.message}")
            false
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Traduction en cours", NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Contrôle du traducteur XG99"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        val micIntent = PendingIntent.getService(this, 1, intent(this, ACTION_START_MIC), flags)
        val systemIntent = if (projection != null) {
            PendingIntent.getService(this, 2, intent(this, ACTION_START_SYSTEM), flags)
        } else {
            // Sans autorisation de capture, il faut passer par l'écran de consentement Android.
            PendingIntent.getActivity(
                this, 3,
                Intent(this, MainActivity::class.java)
                    .setAction(MainActivity.ACTION_REQUEST_SYSTEM)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
                flags
            )
        }
        val stopIntent = PendingIntent.getService(this, 4, intent(this, ACTION_STOP), flags)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Traducteur XG99 — ${mode.label}")
            .setContentText("${Prefs.source(this).label} → ${Prefs.target(this).label}")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(openApp)
            .addAction(0, "🎙 Micro", micIntent)
            .addAction(0, "📱 Système", systemIntent)
            .addAction(0, "⏹ Stop", stopIntent)
            .build()
    }

    private fun updateNotification() {
        if (currentFgsTypes == -1 || shuttingDown) return
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        } catch (ignored: Exception) {
        }
    }

    /* ---------------- MediaProjection (son système) ---------------- */

    private fun handleProjection(intent: Intent) {
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data: Intent? = intent.parcelable<Intent>(EXTRA_RESULT_DATA)
        if (data == null) {
            AppState.log("❌ Autorisation de capture invalide")
            ensureForeground()
            return
        }

        // Android 14+ : le service doit être de type mediaProjection AVANT getMediaProjection().
        projectionGrantPending = true
        val ok = ensureForeground()
        projectionGrantPending = false
        if (!ok) {
            stopSelf()
            return
        }

        try {
            releaseProjection()
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = manager.getMediaProjection(resultCode, data)
            if (p == null) {
                AppState.log("❌ MediaProjection indisponible")
                ensureForeground()
                return
            }
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    if (projection === p) {
                        projection = null
                        AppState.hasProjection.value = false
                        AppState.log("Capture du son système arrêtée par Android")
                        if (mode == Mode.SYSTEM) switchTo(Mode.PAUSED) else updateNotification()
                    }
                }
            }, main)
            projection = p
            AppState.hasProjection.value = true
            AppState.log("✅ Capture du son du téléphone autorisée")
            switchTo(Mode.SYSTEM)
        } catch (e: Exception) {
            AppState.log("❌ Erreur MediaProjection : ${e.message}")
            ensureForeground()
        }
    }

    private fun releaseProjection() {
        val old = projection
        projection = null
        AppState.hasProjection.value = false
        try {
            old?.stop()
        } catch (ignored: Exception) {
        }
    }

    /* ---------------- Changement de mode ---------------- */

    private fun cycle() {
        val next = when (mode) {
            Mode.MIC -> if (projection != null) Mode.SYSTEM else Mode.PAUSED
            Mode.SYSTEM -> Mode.PAUSED
            else -> Mode.MIC
        }
        switchTo(next)
    }

    private fun switchTo(newMode: Mode) {
        if (shuttingDown) return

        if (newMode == Mode.SYSTEM && projection == null) {
            AppState.log("⚠️ Mode Système : ouvrez l'app et appuyez sur « Traduire le son du téléphone » pour autoriser la capture")
            openAppForProjection()
            return
        }
        if (newMode == Mode.MIC || newMode == Mode.SYSTEM) {
            if (Prefs.apiKey(this).isBlank()) {
                AppState.log("❌ Clé API Gemini manquante")
                return
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                AppState.log("❌ Permission micro manquante")
                return
            }
        }

        stopSession()
        mode = newMode
        AppState.mode.value = newMode
        AppState.log("Mode : ${newMode.label}")

        if (newMode == Mode.MIC || newMode == Mode.SYSTEM) {
            ensureForeground()
            startSession(newMode)
        }
        updateMediaSessionState()
        updateNotification()
    }

    private fun openAppForProjection() {
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .setAction(MainActivity.ACTION_REQUEST_SYSTEM)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            )
        } catch (ignored: Exception) {
        }
    }

    private fun shutdown() {
        shuttingDown = true
        stopSession()
        releaseProjection()
        mode = Mode.IDLE
        AppState.mode.value = Mode.IDLE
        AppState.log("Service arrêté")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    /* ---------------- Session de traduction ---------------- */

    private fun startSession(m: Mode) {
        val gen = ++sessionGen
        reconnectAttempts = 0
        acquireWakeLock()

        // Mode Système + « voix du traducteur seule » : la traduction passe par le canal
        // « communication » des écouteurs, et le son média d'origine est coupé.
        val translatorOnly = m == Mode.SYSTEM && Prefs.muteOriginal(this)
        if (m == Mode.MIC || translatorOnly) routeToBluetooth() else releaseRouting()

        val usage = if (m == Mode.MIC || translatorOnly) {
            AudioAttributes.USAGE_VOICE_COMMUNICATION   // sortie vers le casque BT (SCO / LE)
        } else {
            AudioAttributes.USAGE_MEDIA                 // sortie A2DP haute qualité
        }
        player = PcmPlayer(usage)

        if (m == Mode.SYSTEM) {
            if (translatorOnly) muteOriginalAudio() else requestDucking()
        }

        val recorder = createRecorder(m)
        if (recorder == null) {
            AppState.log("❌ Impossible d'ouvrir l'entrée audio")
            main.post { switchTo(Mode.PAUSED) }
            return
        }
        startCapture(recorder, watchSilence = translatorOnly)
        connectClient(gen, m)
    }

    private fun stopSession() {
        sessionGen++
        capturing = false
        captureThread?.let {
            try {
                it.join(600)
            } catch (ignored: InterruptedException) {
            }
        }
        captureThread = null

        client?.close()
        client = null

        player?.release()
        player = null

        echoCanceler?.release()
        echoCanceler = null
        noiseSuppressor?.release()
        noiseSuppressor = null

        abandonDucking()
        restoreOriginalAudio()
        releaseRouting()
        releaseWakeLock()
    }

    private fun connectClient(gen: Int, m: Mode) {
        val c = GeminiLiveClient(
            apiKey = Prefs.apiKey(this),
            model = Prefs.model(this),
            source = Prefs.source(this),
            target = Prefs.target(this),
            bidirectional = m == Mode.MIC,
            listener = object : GeminiLiveClient.Listener {
                override fun onReady() {
                    main.post {
                        if (gen == sessionGen) {
                            reconnectAttempts = 0
                            AppState.log(
                                if (m == Mode.MIC) "✅ Gemini prêt — parlez dans vos écouteurs"
                                else "✅ Gemini prêt — lancez la vidéo / l'audio"
                            )
                        }
                    }
                }

                override fun onAudio(pcm: ByteArray) {
                    if (gen == sessionGen) player?.enqueue(pcm)
                }

                override fun onInterrupted() {
                    if (gen == sessionGen) player?.flush()
                }

                override fun onClosed(code: Int, reason: String) {
                    main.post { onClientClosed(gen, code, reason) }
                }
            }
        )
        client = c
        AppState.log("Connexion à Gemini Live…")
        c.connect()
    }

    private fun onClientClosed(gen: Int, code: Int, reason: String) {
        if (gen != sessionGen || (mode != Mode.MIC && mode != Mode.SYSTEM)) return
        AppState.log("Connexion fermée ($code) ${reason.take(200)}")
        client = null
        reconnectAttempts++
        if (reconnectAttempts > MAX_RECONNECT) {
            AppState.log("❌ Échecs répétés — pause. Vérifiez la clé API, le modèle et Internet.")
            switchTo(Mode.PAUSED)
            return
        }
        val currentMode = mode
        main.postDelayed({
            if (gen == sessionGen && mode == currentMode) {
                AppState.log("Reconnexion (essai $reconnectAttempts/$MAX_RECONNECT)…")
                connectClient(gen, currentMode)
            }
        }, 1000L * reconnectAttempts)
    }

    /* ---------------- Capture audio ---------------- */

    @SuppressLint("MissingPermission")
    private fun createRecorder(m: Mode): AudioRecord? {
        return try {
            val min = AudioRecord.getMinBufferSize(
                IN_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val size = maxOf(min, CHUNK_BYTES) * 4
            val format = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(IN_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .build()

            val recorder = if (m == Mode.MIC) {
                AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(size)
                    .build()
            } else {
                val p = projection ?: return null
                val config = AudioPlaybackCaptureConfiguration.Builder(p)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                AudioRecord.Builder()
                    .setAudioFormat(format)
                    .setBufferSizeInBytes(size)
                    .setAudioPlaybackCaptureConfig(config)
                    .build()
            }

            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release()
                null
            } else {
                if (m == Mode.MIC) enableVoiceEffects(recorder.audioSessionId)
                recorder
            }
        } catch (e: Exception) {
            AppState.log("Erreur AudioRecord : ${e.message}")
            null
        }
    }

    private fun enableVoiceEffects(sessionId: Int) {
        try {
            if (AcousticEchoCanceler.isAvailable()) {
                echoCanceler = AcousticEchoCanceler.create(sessionId)?.also { it.setEnabled(true) }
                AppState.log("Anti-écho (AEC) activé")
            } else {
                AppState.log("Anti-écho matériel non disponible sur ce téléphone")
            }
            if (NoiseSuppressor.isAvailable()) {
                noiseSuppressor = NoiseSuppressor.create(sessionId)?.also { it.setEnabled(true) }
            }
        } catch (e: Exception) {
            AppState.log("Effets audio indisponibles : ${e.message}")
        }
    }

    private fun startCapture(recorder: AudioRecord, watchSilence: Boolean) {
        capturing = true
        val thread = Thread({
            val buffer = ByteArray(CHUNK_BYTES)
            var silentChunks = 0
            var warned = false
            try {
                recorder.startRecording()
                while (capturing) {
                    val n = recorder.read(buffer, 0, buffer.size)
                    if (n > 0) {
                        if (watchSilence && !warned) {
                            var allZero = true
                            for (i in 0 until n) {
                                if (buffer[i].toInt() != 0) {
                                    allZero = false
                                    break
                                }
                            }
                            silentChunks = if (allZero) silentChunks + 1 else 0
                            if (silentChunks >= 100) { // 10 secondes de silence absolu
                                warned = true
                                AppState.log(
                                    "⚠️ Aucun son capté depuis 10 s. Si une vidéo joue, votre téléphone " +
                                        "coupe aussi la capture : désactivez « Voix du traducteur seule »."
                                )
                            }
                        }
                        client?.sendAudio(buffer, n)
                    } else if (n < 0) {
                        AppState.log("Erreur de lecture audio ($n)")
                        Thread.sleep(50)
                    }
                }
            } catch (e: Exception) {
                if (capturing) AppState.log("Capture interrompue : ${e.message}")
            } finally {
                try {
                    recorder.stop()
                } catch (ignored: Exception) {
                }
                recorder.release()
            }
        }, "xg99-capture")
        captureThread = thread
        thread.start()
    }

    /* ---------------- Routage Bluetooth (micro XG99) ---------------- */

    @Suppress("DEPRECATION")
    private fun routeToBluetooth() {
        try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            if (Build.VERSION.SDK_INT >= 31) {
                val candidates = audioManager.availableCommunicationDevices.filter {
                    it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || it.type == AudioDeviceInfo.TYPE_BLE_HEADSET
                }
                val device = candidates.firstOrNull {
                    it.productName.toString().contains("XG99", ignoreCase = true)
                } ?: candidates.firstOrNull()
                if (device != null && audioManager.setCommunicationDevice(device)) {
                    routedToBluetooth = true
                    AppState.log("🎧 Écouteurs Bluetooth : ${device.productName}")
                } else {
                    AppState.log("⚠️ Aucun écouteur Bluetooth trouvé — micro du téléphone utilisé")
                }
            } else {
                audioManager.startBluetoothSco()
                audioManager.isBluetoothScoOn = true
                routedToBluetooth = true
                AppState.log("🎧 Activation du micro Bluetooth (SCO)…")
            }
        } catch (e: Exception) {
            AppState.log("Routage Bluetooth impossible : ${e.message}")
        }
    }

    @Suppress("DEPRECATION")
    private fun releaseRouting() {
        try {
            if (routedToBluetooth) {
                if (Build.VERSION.SDK_INT >= 31) {
                    audioManager.clearCommunicationDevice()
                } else {
                    audioManager.isBluetoothScoOn = false
                    audioManager.stopBluetoothSco()
                }
                routedToBluetooth = false
            }
            audioManager.mode = AudioManager.MODE_NORMAL
        } catch (ignored: Exception) {
        }
    }

    /* ---------------- Ducking (baisse du son de la vidéo) ---------------- */

    private fun requestDucking() {
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attributes)
            .setOnAudioFocusChangeListener(AudioManager.OnAudioFocusChangeListener { }, main)
            .build()
        val result = audioManager.requestAudioFocus(request)
        focusRequest = request
        AppState.log(
            if (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) "🔉 Volume de la vidéo d'origine baissé"
            else "Baisse du volume refusée par Android"
        )
    }

    private fun abandonDucking() {
        focusRequest?.let {
            try {
                audioManager.abandonAudioFocusRequest(it)
            } catch (ignored: Exception) {
            }
        }
        focusRequest = null
    }

    /* ---------------- Coupure du son d'origine ---------------- */

    private fun muteOriginalAudio() {
        try {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            mediaMuted = true
            AppState.log("🔇 Son de la vidéo coupé — vous n'entendez que le traducteur (volume : touches du téléphone)")
        } catch (e: Exception) {
            AppState.log("Impossible de couper le son d'origine : ${e.message}")
            requestDucking()
        }
    }

    private fun restoreOriginalAudio() {
        if (!mediaMuted) return
        try {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
        } catch (ignored: Exception) {
        }
        mediaMuted = false
    }

    /* ---------------- Wake lock (écran éteint) ---------------- */

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "XG99:translator").apply {
            setReferenceCounted(false)
            acquire(6L * 60 * 60 * 1000)
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
        wakeLock = null
    }

    /* ---------------- Boutons des écouteurs (MediaSession) ---------------- */

    private fun setupMediaSession() {
        mediaSession = MediaSession(this, "XG99Translator")
        mediaSession.setCallback(object : MediaSession.Callback() {
            override fun onMediaButtonEvent(mediaButtonIntent: Intent): Boolean {
                val event: KeyEvent = mediaButtonIntent.parcelable<KeyEvent>(Intent.EXTRA_KEY_EVENT)
                    ?: return super.onMediaButtonEvent(mediaButtonIntent)
                if (event.action != KeyEvent.ACTION_DOWN) return true
                if (event.repeatCount > 0) return true
                when (event.keyCode) {
                    KeyEvent.KEYCODE_HEADSETHOOK,
                    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                    KeyEvent.KEYCODE_MEDIA_PLAY,
                    KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                        AppState.log("🎛 Appui écouteur → mode suivant")
                        cycle()
                    }
                    KeyEvent.KEYCODE_MEDIA_NEXT -> {
                        AppState.log("🎛 Écouteur : suivant → Système")
                        switchTo(Mode.SYSTEM)
                    }
                    KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                        AppState.log("🎛 Écouteur : précédent → Micro")
                        switchTo(Mode.MIC)
                    }
                    KeyEvent.KEYCODE_MEDIA_STOP -> switchTo(Mode.PAUSED)
                    else -> return super.onMediaButtonEvent(mediaButtonIntent)
                }
                return true
            }

            override fun onPlay() = cycle()
            override fun onPause() = switchTo(Mode.PAUSED)
            override fun onSkipToNext() = switchTo(Mode.SYSTEM)
            override fun onSkipToPrevious() = switchTo(Mode.MIC)
            override fun onStop() = switchTo(Mode.PAUSED)
        }, main)
        updateMediaSessionState()
        mediaSession.isActive = true
    }

    private fun updateMediaSessionState() {
        val active = mode == Mode.MIC || mode == Mode.SYSTEM
        val actions = PlaybackState.ACTION_PLAY or
            PlaybackState.ACTION_PAUSE or
            PlaybackState.ACTION_PLAY_PAUSE or
            PlaybackState.ACTION_SKIP_TO_NEXT or
            PlaybackState.ACTION_SKIP_TO_PREVIOUS or
            PlaybackState.ACTION_STOP
        mediaSession.setPlaybackState(
            PlaybackState.Builder()
                .setActions(actions)
                .setState(
                    if (active) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                    PlaybackState.PLAYBACK_POSITION_UNKNOWN,
                    1f
                )
                .build()
        )
        mediaSession.setMetadata(
            MediaMetadata.Builder()
                .putString(MediaMetadata.METADATA_KEY_TITLE, "Traducteur XG99")
                .putString(MediaMetadata.METADATA_KEY_ARTIST, mode.label)
                .build()
        )
    }
}
