package com.xg99.translator

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/* ============================================================
 *  État global partagé entre le Service et l'interface Compose
 * ============================================================ */

enum class Mode(val label: String) {
    IDLE("Arrêté"),
    MIC("Micro (écouteurs)"),
    SYSTEM("Son du téléphone"),
    PAUSED("En pause")
}

object AppState {
    val mode = MutableStateFlow(Mode.IDLE)
    val hasProjection = MutableStateFlow(false)
    val logs = MutableStateFlow<List<String>>(emptyList())

    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun log(message: String) {
        Log.i("XG99", message)
        val time = synchronized(timeFormat) { timeFormat.format(Date()) }
        val line = "$time  $message"
        logs.update { current -> (listOf(line) + current).take(300) }
    }
}

/* ============================================================
 *  Langues
 * ============================================================ */

data class Lang(val code: String, val label: String, val english: String)

val LANGUAGES = listOf(
    Lang("fr", "Français", "French"),
    Lang("en", "English", "English"),
    Lang("es", "Español", "Spanish"),
    Lang("ar", "العربية (Arabe)", "Arabic"),
    Lang("zh", "中文 (Mandarin)", "Mandarin Chinese"),
    Lang("de", "Deutsch", "German"),
    Lang("it", "Italiano", "Italian"),
    Lang("pt", "Português", "Portuguese"),
    Lang("ru", "Русский", "Russian"),
    Lang("ja", "日本語", "Japanese"),
    Lang("ko", "한국어", "Korean"),
    Lang("hi", "हिन्दी", "Hindi"),
    Lang("tr", "Türkçe", "Turkish"),
    Lang("nl", "Nederlands", "Dutch"),
    Lang("pl", "Polski", "Polish")
)

fun langOf(code: String?): Lang = LANGUAGES.firstOrNull { it.code == code } ?: LANGUAGES[0]

/* ============================================================
 *  Préférences (SharedPreferences)
 * ============================================================ */

object Prefs {
    const val DEFAULT_MODEL = "gemini-3.5-live-translate-preview"
    const val KEY_API = "api_key"
    const val KEY_MODEL = "model"
    const val KEY_SRC = "source_lang"
    const val KEY_TGT = "target_lang"
    const val KEY_MUTE_ORIGINAL = "mute_original"

    private fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("xg99_settings", Context.MODE_PRIVATE)

    fun apiKey(c: Context): String = sp(c).getString(KEY_API, "")?.trim() ?: ""

    fun model(c: Context): String {
        val m = sp(c).getString(KEY_MODEL, DEFAULT_MODEL)?.trim().orEmpty()
        return m.removePrefix("models/").ifBlank { DEFAULT_MODEL }
    }

    fun source(c: Context): Lang = langOf(sp(c).getString(KEY_SRC, "fr"))

    fun target(c: Context): Lang = langOf(sp(c).getString(KEY_TGT, "en"))

    fun muteOriginal(c: Context): Boolean = sp(c).getBoolean(KEY_MUTE_ORIGINAL, true)

    fun saveBool(c: Context, key: String, value: Boolean) {
        sp(c).edit().putBoolean(key, value).apply()
    }

    fun save(c: Context, key: String, value: String) {
        sp(c).edit().putString(key, value).apply()
    }
}

/* ============================================================
 *  Client WebSocket — Gemini Live API (BidiGenerateContent)
 *  Entrée : PCM 16 bits / 16 kHz / mono
 *  Sortie : PCM 16 bits / 24 kHz / mono
 * ============================================================ */

class GeminiLiveClient(
    private val apiKey: String,
    private val model: String,
    private val source: Lang,
    private val target: Lang,
    private val bidirectional: Boolean,
    private val listener: Listener
) {

    interface Listener {
        fun onReady()
        fun onAudio(pcm: ByteArray)
        fun onInterrupted()
        fun onClosed(code: Int, reason: String)
    }

    companion object {
        private const val ENDPOINT =
            "wss://generativelanguage.googleapis.com/ws/" +
                "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"

        private val http: OkHttpClient by lazy {
            OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .pingInterval(20, TimeUnit.SECONDS)
                .build()
        }
    }

    @Volatile
    private var webSocket: WebSocket? = null

    @Volatile
    var isReady: Boolean = false
        private set

    @Volatile
    private var intentionalClose = false

    private val closedNotified = AtomicBoolean(false)
    private val transcriptLock = Any()
    private val inputText = StringBuilder()
    private val outputText = StringBuilder()

    private val isTranslateModel: Boolean
        get() = model.contains("translate", ignoreCase = true)

    fun connect() {
        val url = ENDPOINT + "?key=" + URLEncoder.encode(apiKey.trim(), "UTF-8")
        val request = Request.Builder().url(url).build()
        webSocket = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                webSocket.send(buildSetupMessage())
                AppState.log("WebSocket ouvert — configuration envoyée ($model)")
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                handleMessage(text)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                handleMessage(bytes.utf8())
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
                notifyClosed(code, reason)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                notifyClosed(code, reason)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val prefix = if (response != null) "HTTP ${response.code} " else ""
                notifyClosed(-1, prefix + (t.message ?: t.javaClass.simpleName))
            }
        })
    }

    fun sendAudio(buffer: ByteArray, length: Int) {
        val ws = webSocket ?: return
        if (!isReady || length <= 0) return
        val b64 = Base64.encodeToString(buffer, 0, length, Base64.NO_WRAP)
        ws.send("{\"realtimeInput\":{\"audio\":{\"data\":\"$b64\",\"mimeType\":\"audio/pcm;rate=16000\"}}}")
    }

    fun close() {
        intentionalClose = true
        isReady = false
        try {
            webSocket?.close(1000, "stop")
        } catch (ignored: Exception) {
        }
        webSocket = null
        flushTranscripts(force = true)
    }

    private fun notifyClosed(code: Int, reason: String) {
        isReady = false
        if (closedNotified.compareAndSet(false, true) && !intentionalClose) {
            flushTranscripts(force = true)
            listener.onClosed(code, reason)
        }
    }

    private fun buildSetupMessage(): String {
        val setup = JSONObject()
        setup.put("model", "models/$model")

        val generation = JSONObject()
        generation.put("responseModalities", JSONArray().put("AUDIO"))

        if (isTranslateModel) {
            // Modèle de traduction dédié : configuration simplifiée, pas d'instructions système.
            setup.put("inputAudioTranscription", JSONObject())
            setup.put("outputAudioTranscription", JSONObject())
            generation.put(
                "translationConfig",
                JSONObject()
                    .put("targetLanguageCode", target.code)
                    .put("echoTargetLanguage", false)
            )
            setup.put("generationConfig", generation)
        } else {
            // Modèle conversationnel (ex. gemini-3.8-live) piloté par instructions système.
            setup.put("generationConfig", generation)
            setup.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", buildPrompt())))
            )
            setup.put("inputAudioTranscription", JSONObject())
            setup.put("outputAudioTranscription", JSONObject())
            setup.put("realtimeInputConfig", JSONObject().put("activityHandling", "NO_INTERRUPTION"))
            setup.put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
        }

        return JSONObject().put("setup", setup).toString()
    }

    private fun buildPrompt(): String {
        val rules = if (bidirectional) {
            "When you hear ${source.english}, say the translation in ${target.english}. " +
                "When you hear ${target.english}, say the translation in ${source.english}. " +
                "Any other language: translate into ${target.english}."
        } else {
            "Translate everything you hear into ${target.english}."
        }
        return "You are a professional real-time simultaneous interpreter, not an assistant. " +
            rules +
            " Output ONLY the spoken translation, faithfully and naturally, keeping the speaker's tone. " +
            "Never answer questions, never comment, never greet, never explain. " +
            "If you hear only music, noise or silence, stay completely silent."
    }

    private fun handleMessage(raw: String) {
        try {
            val msg = JSONObject(raw)

            if (msg.has("setupComplete")) {
                isReady = true
                listener.onReady()
            }

            val content = msg.optJSONObject("serverContent")
            if (content != null) {
                if (content.optBoolean("interrupted", false)) {
                    listener.onInterrupted()
                }

                val parts = content.optJSONObject("modelTurn")?.optJSONArray("parts")
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                        val data = inline.optString("data", "")
                        if (data.isNotEmpty()) {
                            listener.onAudio(Base64.decode(data, Base64.DEFAULT))
                        }
                    }
                }

                val inText = content.optJSONObject("inputTranscription")?.optString("text", "").orEmpty()
                val outText = content.optJSONObject("outputTranscription")?.optString("text", "").orEmpty()
                synchronized(transcriptLock) {
                    if (inText.isNotEmpty()) inputText.append(inText)
                    if (outText.isNotEmpty()) outputText.append(outText)
                }

                val turnDone = content.optBoolean("turnComplete", false) ||
                    content.optBoolean("generationComplete", false)
                flushTranscripts(force = turnDone)
            }

            if (msg.has("goAway")) {
                AppState.log("Le serveur va fermer la session — reconnexion automatique")
            }

            val error = msg.optJSONObject("error")
            if (error != null) {
                AppState.log("Erreur serveur : " + error.optString("message", error.toString()))
            }
        } catch (e: Exception) {
            AppState.log("Message serveur illisible : ${e.message}")
        }
    }

    private fun flushTranscripts(force: Boolean) {
        synchronized(transcriptLock) {
            if (inputText.isNotBlank() && (force || endsSentence(inputText))) {
                AppState.log("🗣 " + inputText.toString().trim())
                inputText.setLength(0)
            }
            if (outputText.isNotBlank() && (force || endsSentence(outputText))) {
                AppState.log("🔊 " + outputText.toString().trim())
                outputText.setLength(0)
            }
        }
    }

    private fun endsSentence(sb: StringBuilder): Boolean {
        val t = sb.toString().trimEnd()
        return t.length > 25 && t.last() in ".?!。？！"
    }
}
